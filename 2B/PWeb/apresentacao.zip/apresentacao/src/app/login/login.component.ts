import { Component } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';

@Component({
  selector: 'app-login',
  imports: [ReactiveFormsModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
  loginForms: FormGroup = new FormGroup({});
  constructor(private fb: FormGroup) {
    this.loginForms = new FormGroup({
      email: new FormControl(''),
      password: new FormControl('')
    });
  }
  initializeForm() {
    const formValues = this.loginForms.value;
    const email = formValues.get('email')?.value;
    const password = formValues.get('password')?.value;
    console.log('Email:', email);
  }
}
